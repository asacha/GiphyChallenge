package com.ascstb.server

import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import javax.inject.Singleton

@Module
object BackgroundLauncherModule {

    @JvmStatic
    @Provides
    @Singleton
    fun launchInBackground(): BackgroundLauncher = object : BackgroundLauncher {
        override fun launch(block: suspend CoroutineScope.() -> Unit): Job =
            GlobalScope.launch { block(this) }
    }
}

//We need an interface cause Dagger does not behave well with first order functions as type
interface BackgroundLauncher {
    fun launch(block: suspend CoroutineScope.() -> Unit): Job
}