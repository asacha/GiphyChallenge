package com.ascstb.server

import dagger.Module
import dagger.Provides
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
class HttpClientModule {
    @Provides
    @Named(HTTP_CLIENT)
    @Singleton
    fun httpClient() = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply { level = logLevel })
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
}

private val logLevel =
    if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
    else HttpLoggingInterceptor.Level.NONE

const val HTTP_CLIENT = "http-client"