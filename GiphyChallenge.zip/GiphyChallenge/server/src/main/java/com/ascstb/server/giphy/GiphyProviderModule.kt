package com.ascstb.server.giphy

import com.ascstb.data.provider.GiphyProvider
import dagger.Binds
import dagger.Module
import javax.inject.Singleton

@Module
abstract class GiphyProviderModule {
    @Binds
    @Singleton
    abstract fun giphyProvider(giphyProvider: GiphyDataProvider): GiphyProvider
}