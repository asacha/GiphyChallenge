package com.ascstb.server.giphy

import kotlinx.coroutines.Deferred
import retrofit2.http.GET
import retrofit2.http.Query

interface GiphyApi {
    @GET("v1/gifs/search")
    fun searchGifsAsync(
        @Query(value = "api_key") apiKey: String,
        @Query(value = "q") query: String,
        @Query(value = "limit") limit: String,
        @Query(value = "offset") offset: String,
        @Query(value = "lang") language: String,
        @Query(value = "fmt") format: String
    ) : Deferred<GiphyResponse>
}