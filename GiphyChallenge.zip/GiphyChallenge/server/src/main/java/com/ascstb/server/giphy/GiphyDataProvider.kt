package com.ascstb.server.giphy

import com.ascstb.data.domain.Gif
import com.ascstb.data.provider.GiphyProvider
import com.ascstb.server.BuildConfig
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import java.lang.Exception
import javax.inject.Inject

class GiphyDataProvider @Inject constructor(
    private val giphyApi: GiphyApi
) : GiphyProvider {

    override fun searchGifsAsync(query: String, language: String): Deferred<com.ascstb.data.Result<List<Gif>>> =
        GlobalScope.async {
            try {
                giphyApi.searchGifsAsync(
                    apiKey = BuildConfig.GIPHY_API_KEY,
                    query = query,
                    limit = BuildConfig.GIPHY_LIMIT,
                    offset = BuildConfig.GIPHY_OFFSET,
                    language = language,
                    format = "json"
                ).await().data.map { data ->
                    Gif(
                        type = data.type,
                        id = data.id,
                        url = changeFormat(data.embedUrl),
                        embedUrl = data.embedUrl,
                        title = data.title
                    )
                }.run {
                    com.ascstb.data.Result.Ok(this)
                }
            } catch (e: Exception) {
                com.ascstb.data.Result.Err(e)
            }
        }

    private fun changeFormat(originalUrl: String): String {
        return "https://media.giphy.com/media/${originalUrl.replace("https://giphy.com/embed/", "")}/giphy.gif"
    }
}