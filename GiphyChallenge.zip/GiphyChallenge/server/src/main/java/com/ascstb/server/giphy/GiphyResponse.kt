package com.ascstb.server.giphy

import android.support.annotation.Keep
import com.squareup.moshi.Json

@Keep
data class GiphyResponse (
    @Json(name = "data") val data: List<Data>
)

@Keep
data class Data(
    @Json(name = "type") val type: String,
    @Json(name = "id") val id: String,
    @Json(name = "url") val url: String,
    @Json(name = "embed_url") val embedUrl: String,
    @Json(name = "title") val title: String
)