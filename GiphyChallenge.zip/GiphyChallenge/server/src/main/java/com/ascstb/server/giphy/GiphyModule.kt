package com.ascstb.server.giphy

import com.ascstb.server.*
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import javax.inject.Named
import javax.inject.Singleton

@Module
class GiphyModule {
    @Provides
    @Singleton
    fun giphyApi(@Named(GIPHY_RETROFIT) retrofit: Retrofit) = retrofit.create(GiphyApi::class.java)

    @Provides
    @Named(GIPHY_RETROFIT)
    @Singleton
    fun retrofit(@Named(HTTP_CLIENT) okHttpClient: OkHttpClient, @Named(GIPHY_MOSHI) moshi: Moshi) =
            Retrofit.Builder()
                .baseUrl(BuildConfig.GIPHY_BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(UnitConverterFactory)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .addCallAdapterFactory(CoroutineCallAdapterFactory.invoke())
                .build()

    @Provides
    @Named(GIPHY_MOSHI)
    @Singleton
    fun moshi(): Moshi = Moshi.Builder()
        .add(JsonNameAsStringAdapter)
        .add(NullIfEmptyStringAdapter)
        .add(KotlinJsonAdapterFactory())
        .build()
}

const val GIPHY_RETROFIT = "giphy.retrofit"
const val GIPHY_MOSHI = "giphy.moshi"
//const val BASE_URL = "https://api.giphy.com/"