package com.ascstb.basedagger

import javax.inject.Scope

const val APPLICATION_CONTEXT = "dagger.application-context"
const val ACTIVITY_CONTEXT = "dagger.activity-context"
const val SERVICE_CONTEXT = "dagger.service-context"

@Scope
@Retention
annotation class ActivityScope

@Scope
@Retention
annotation class FragmentScope

@Scope
@Retention
annotation class ChildFragmentScope