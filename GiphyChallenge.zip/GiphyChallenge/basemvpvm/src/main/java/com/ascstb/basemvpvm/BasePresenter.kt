package com.ascstb.basemvpvm

import android.support.annotation.MainThread
import android.support.annotation.VisibleForTesting
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import timber.log.Timber
import kotlin.coroutines.CoroutineContext

abstract class BasePresenter<VM : MvpViewModel>(val viewModel: VM) : MvpPresenter, CoroutineScope {

    private lateinit var job: Job
    override lateinit var coroutineContext: CoroutineContext
    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    var launcher: (suspend CoroutineScope.() -> Unit) -> Unit = { block ->
        launch { block(this) }
    }

    @MainThread
    override fun start() {
        Timber.d("started: ${this}")
        job = Job()
        coroutineContext = job + Dispatchers.Main
    }

    @MainThread
    override fun resume() {
        Timber.d("resumed: ${this}")
    }

    @MainThread
    override fun pause() {
        Timber.d("paused: ${this}")
    }

    @MainThread
    override fun stop() {
        Timber.d("stopped:  ${this}")
        job.cancel()
    }

    fun background(block: suspend CoroutineScope.() -> Unit) {
        launcher(block)
    }
}