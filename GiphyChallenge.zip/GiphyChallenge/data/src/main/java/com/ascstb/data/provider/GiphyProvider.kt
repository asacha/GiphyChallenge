package com.ascstb.data.provider

import com.ascstb.data.Result
import com.ascstb.data.domain.Gif
import kotlinx.coroutines.Deferred

interface GiphyProvider {
    fun searchGifsAsync(query: String, language: String): Deferred<Result<List<Gif>>>
}