package com.ascstb.data

import java.lang.Exception

sealed class Result<out R> {
    class Err(val error: Exception) : Result<Nothing>()
    class Ok<out R>(val result: R) : Result<R>()

    fun <M> map(mapFunctions: (R) -> M): Result<M> = when (this) {
        is Err -> this
        is Ok -> Ok(mapFunctions(result))
    }

    fun unfold(): R = when (this) {
        is Err -> throw error
        is Ok -> result
    }
}

sealed class EmptyResult {
    class Err(val error: Exception) : EmptyResult()
    object Ok : EmptyResult()
}