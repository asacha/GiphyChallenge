package com.ascstb.data.domain

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class Gif (
    var type: String?,
    var id: String?,
    var url: String?,
    var embedUrl: String?,
    var title: String?
): Parcelable