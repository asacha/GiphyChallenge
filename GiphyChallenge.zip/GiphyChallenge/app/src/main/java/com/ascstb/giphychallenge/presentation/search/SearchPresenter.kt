package com.ascstb.giphychallenge.presentation.search

import com.ascstb.basedagger.FragmentScope
import com.ascstb.basemvpvm.BasePresenter
import com.ascstb.data.Result
import com.ascstb.data.domain.Gif
import com.ascstb.data.provider.GiphyProvider
import com.ascstb.giphychallenge.presentation.Navigation
import com.ascstb.giphychallenge.utils.runOnResult
import timber.log.Timber
import javax.inject.Inject

@FragmentScope
class SearchPresenter @Inject constructor(
    viewModel: SearchViewModel,
    private val navigation: Navigation,
    private val giphyProvider: GiphyProvider
) : BasePresenter<SearchViewModel>(viewModel) {
    override fun start() {
        super.start()

        Timber.d("SearchPresenter_TAG: start")
        fetchGifs()
    }

    fun fetchGifs() = background {
        giphyProvider.searchGifsAsync(
            query = viewModel.query,
            language = "en"
        ).runOnResult {
            when (this) {
                is Result.Err -> error.printStackTrace()
                is Result.Ok -> {
                    Timber.d("SearchPresenter_TAG: fetchGifs: ${result.size}")
                    viewModel.availableGifs = result
                    for (gif in viewModel.availableGifs) {
                        Timber.d("SearchPresenter_TAG: fetchGifs: ${gif.url}")
                    }
                }
            }
        }
    }

    fun gifClicked(gif: Gif) {
        Timber.d("SearchPresenter_TAG: gifClicked: $gif")
    }
}