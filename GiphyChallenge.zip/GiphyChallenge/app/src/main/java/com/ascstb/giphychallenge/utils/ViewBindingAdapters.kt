package com.ascstb.giphychallenge.utils

import android.databinding.BindingAdapter
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.squareup.picasso.Callback
import com.squareup.picasso.Picasso
import timber.log.Timber

@BindingAdapter(value = ["imageUrl", "placeHolder"], requireAll = false)
fun imageURL(view: ImageView, imageUrl: String?, placeHolder: Int = 0) {
    Timber.d("Picasso URL: $imageUrl")
    if (!imageUrl.isNullOrEmpty()) {
        when (placeHolder) {
            0 -> Picasso.get()
                .load(imageUrl)
            else -> Picasso.get()
                .load(imageUrl)
                .placeholder(placeHolder)
        }.run {
            into(view, object : Callback.EmptyCallback() {
                override fun onSuccess() {}

                override fun onError(e: Exception?) {}
            })
        }
    } else {
        view.setImageDrawable(null)
    }
}

@BindingAdapter(value = ["gifUrl", "placeHolder"], requireAll = false)
fun gifURL(view: ImageView, imageUrl: String?, placeHolder: Int = 0) {
    Timber.d("_TAG: gifURL: $imageUrl")
    if (!imageUrl.isNullOrEmpty()) {
        Glide
            .with(view.context)
            .load(imageUrl)
            .override(240, 240)
            .into(view)
    } else {
        view.setImageDrawable(null)
    }
}