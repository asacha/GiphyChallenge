package com.ascstb.giphychallenge.core

import com.ascstb.basedagger.FragmentScope
import com.ascstb.giphychallenge.presentation.search.SearchModule
import com.ascstb.giphychallenge.presentation.search.SearchView
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
internal abstract class FragmentBuilderModule {

    @FragmentScope
    @ContributesAndroidInjector(modules = [SearchModule::class])
    internal abstract fun searchView(): SearchView
}