package com.ascstb.giphychallenge.core

import android.app.Activity
import android.app.Application
import android.app.Service
import com.ascstb.giphychallenge.BuildConfig
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasActivityInjector
import dagger.android.HasServiceInjector
import timber.log.Timber
import timber.log.Timber.Tree
import javax.inject.Inject

open class MyApp : Application(), HasActivityInjector, HasServiceInjector {

    @Inject
    lateinit var activityInjector: DispatchingAndroidInjector<Activity>
    @Inject
    lateinit var serviceInjector: DispatchingAndroidInjector<Service>
    @Inject
    lateinit var timberTree: Tree

    private val daggerComponent: AppComponent by lazy {
        DaggerAppComponent.builder().create(this) as AppComponent
    }

    override fun onCreate() {
        super.onCreate()

        daggerComponent.inject(this)

        if (BuildConfig.DEBUG) {
            Timber.plant(timberTree)
        }
    }

    override fun activityInjector(): AndroidInjector<Activity> = activityInjector

    override fun serviceInjector(): AndroidInjector<Service> = serviceInjector
}