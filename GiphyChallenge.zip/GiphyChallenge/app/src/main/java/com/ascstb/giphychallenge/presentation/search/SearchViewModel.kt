package com.ascstb.giphychallenge.presentation.search

import android.content.Context
import android.databinding.Bindable
import com.ascstb.basedagger.ACTIVITY_CONTEXT
import com.ascstb.basedagger.FragmentScope
import com.ascstb.basemvpvm.BaseViewModel
import com.ascstb.data.domain.Gif
import com.ascstb.giphychallenge.BR
import javax.inject.Inject
import javax.inject.Named

@FragmentScope
class SearchViewModel @Inject constructor(
    @Named(ACTIVITY_CONTEXT) context: Context
) : BaseViewModel(context) {
    @get:Bindable
    var query: String = ""
        set(value) {
            if (field == value) return
            field = value
            notifyPropertyChanged(BR.query)
        }

    @get:Bindable
    var availableGifs: List<Gif> = emptyList()
        set(value) {
            field = value
            recyclerItemViewModels = value.map { SearchItemViewModel(context).apply { gif = it } }
            notifyPropertyChanged(BR.availableGifs)
        }

    @Bindable(value = ["availableGifs"])
    var recyclerItemViewModels: List<SearchItemViewModel> = emptyList()
        private set
}