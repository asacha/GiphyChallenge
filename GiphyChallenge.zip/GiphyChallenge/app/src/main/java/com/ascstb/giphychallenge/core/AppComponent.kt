package com.ascstb.giphychallenge.core

import com.ascstb.server.HttpClientModule
import com.ascstb.server.giphy.GiphyModule
import com.ascstb.server.giphy.GiphyProviderModule
import dagger.Component
import dagger.android.AndroidInjector
import dagger.android.support.AndroidSupportInjectionModule
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AndroidSupportInjectionModule::class,
        TimberTreeModule::class,

        AppModule::class,
        ActivitiesBuilderModule::class,

        HttpClientModule::class,
        GiphyModule::class,
        GiphyProviderModule::class
    ]
)
interface AppComponent : AndroidInjector<MyApp> {

    @Component.Builder
    abstract class Builder : AndroidInjector.Builder<MyApp>()
}