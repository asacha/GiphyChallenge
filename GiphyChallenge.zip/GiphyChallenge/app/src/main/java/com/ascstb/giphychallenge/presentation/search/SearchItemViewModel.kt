package com.ascstb.giphychallenge.presentation.search

import android.content.Context
import com.ascstb.basedagger.ACTIVITY_CONTEXT
import com.ascstb.basemvpvm.BaseViewModel
import com.ascstb.data.domain.Gif
import javax.inject.Inject
import javax.inject.Named

class SearchItemViewModel @Inject constructor(
    @Named(ACTIVITY_CONTEXT) context: Context
) : BaseViewModel(context) {
    var gif: Gif? = null
        set(value) {
            field = value
            notifyChange()
        }

    val url: String
        get() = gif?.url ?: ""

    val title: String
        get() = gif?.title ?: ""
}