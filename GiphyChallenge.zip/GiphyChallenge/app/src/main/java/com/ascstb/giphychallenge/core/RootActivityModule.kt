package com.ascstb.giphychallenge.core

import com.ascstb.basedagger.ActivityScope
import com.ascstb.basedagger.BaseActivityModule
import com.ascstb.giphychallenge.RootActivity
import com.ascstb.giphychallenge.presentation.Navigation
import dagger.Binds
import dagger.Module

@Module(includes = [
    FragmentBuilderModule::class
])
abstract class RootActivityModule : BaseActivityModule<RootActivity>() {

    @Binds
    @ActivityScope
    abstract fun navigation(activity: RootActivity): Navigation

}