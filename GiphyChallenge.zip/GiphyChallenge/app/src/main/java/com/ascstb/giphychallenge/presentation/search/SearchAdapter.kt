package com.ascstb.giphychallenge.presentation.search

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.ascstb.basedagger.FragmentScope
import com.ascstb.data.domain.Gif
import com.ascstb.giphychallenge.databinding.SearchItemDefaultLayoutBinding

@FragmentScope
class SearchAdapter(
    private val listener: (Gif) -> Unit
) : RecyclerView.Adapter<SearchAdapter.ViewHolder>() {
    var listItems: List<SearchItemViewModel> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    inner class ViewHolder(val itemBinding: SearchItemDefaultLayoutBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(gif: Gif, clickListener: (Gif) -> Unit) {
            itemView.setOnClickListener { clickListener(gif) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder =
        SearchItemDefaultLayoutBinding.inflate(LayoutInflater.from(parent.context)).run {
            ViewHolder(this)
        }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemBinding.viewModel = listItems[position]
        listItems[position].gif?.let { gif ->
            holder.bind(gif, listener)
        }
        holder.itemBinding.executePendingBindings()
    }

    override fun getItemCount(): Int = listItems.size
}