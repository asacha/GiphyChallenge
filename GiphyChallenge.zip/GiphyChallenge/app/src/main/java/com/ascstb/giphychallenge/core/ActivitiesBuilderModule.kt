package com.ascstb.giphychallenge.core

import com.ascstb.basedagger.ActivityScope
import com.ascstb.giphychallenge.RootActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
internal abstract class ActivitiesBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector(modules = [RootActivityModule::class])
    internal abstract fun rootActivity(): RootActivity

}