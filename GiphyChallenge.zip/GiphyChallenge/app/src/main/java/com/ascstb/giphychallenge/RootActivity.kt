package com.ascstb.giphychallenge

import android.os.Bundle
import android.support.v4.app.Fragment
import com.ascstb.basedagger.BaseDaggerActivity
import com.ascstb.giphychallenge.presentation.Navigation
import com.ascstb.giphychallenge.presentation.search.SearchView
import com.ascstb.giphychallenge.utils.commit
import javax.inject.Inject

class RootActivity : BaseDaggerActivity(), Navigation {
    @Inject
    lateinit var navigation: Navigation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.root_activity_layout)

        navigation.navigateToSearch()
    }

    override fun navigateBack() {
        supportFragmentManager.popBackStack()
    }

    override fun navigateToSearch() {
        loadContentFragment(
            fragment = SearchView(),
            tag = Navigation.Screen.SEARCH
        )
    }

    private fun loadContentFragment(fragment: Fragment, tag: Navigation.Screen, addToBackStack: Boolean = true) {
        supportFragmentManager.commit {
            replace(R.id.content, fragment, tag.tag)
            if (addToBackStack) addToBackStack(tag.tag)
        }
    }
}
