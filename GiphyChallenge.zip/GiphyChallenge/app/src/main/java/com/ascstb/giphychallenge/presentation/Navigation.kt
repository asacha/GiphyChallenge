package com.ascstb.giphychallenge.presentation

interface Navigation {
    fun navigateBack()

    fun navigateToSearch()

    enum class Screen(val tag: String) {
        SEARCH("search"),

        OTHER("other"),
        NONE("none")
        ;

        companion object {
            fun fromTag(tag: String?) = values().find { it.tag == tag }
        }
    }
}