package com.ascstb.giphychallenge.core

import dagger.Module
import dagger.Provides
import timber.log.Timber.DebugTree
import timber.log.Timber.Tree


@Module
class TimberTreeModule {
    @Provides
    fun timberTree(): Tree = DebugTree()
}