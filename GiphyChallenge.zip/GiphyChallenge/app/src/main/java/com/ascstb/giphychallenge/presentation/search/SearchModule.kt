package com.ascstb.giphychallenge.presentation.search

import com.ascstb.basedagger.BaseFragmentModule
import dagger.Module

@Module
abstract class SearchModule : BaseFragmentModule<SearchView>()
