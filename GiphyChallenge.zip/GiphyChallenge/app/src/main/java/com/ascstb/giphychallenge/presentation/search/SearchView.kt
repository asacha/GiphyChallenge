package com.ascstb.giphychallenge.presentation.search

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.ascstb.basemvpvm.BaseMvpFragment
import com.ascstb.data.domain.Gif
import com.ascstb.giphychallenge.BR
import com.ascstb.giphychallenge.databinding.SearchLayoutBinding
import timber.log.Timber

class SearchView : BaseMvpFragment<SearchPresenter, SearchViewModel, SearchLayoutBinding>() {
    private lateinit var adapter: SearchAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.onPropertyChanged(BR.query) {
            presenter.fetchGifs()
        }

        adapter.listItems = viewModel.recyclerItemViewModels

        viewModel.onPropertyChanged(BR.availableGifs) {
            Timber.d("SearchView_TAG: onViewCreated: availableGifs: ${viewModel.availableGifs.size}")
            adapter.listItems = viewModel.recyclerItemViewModels
        }
    }

    override fun inflateDataBinding(inflater: LayoutInflater, container: ViewGroup?): SearchLayoutBinding =
        SearchLayoutBinding.inflate(layoutInflater, container, false).also { layout ->
            this.adapter = SearchAdapter { gif: Gif ->
                presenter.gifClicked(gif)
                shareGif(gif)
            }
            layout.rv.layoutManager =
                activity?.applicationContext?.let { ctx ->
                    GridLayoutManager(ctx, 4)
                }
            layout.rv.adapter = adapter
        }

    private fun shareGif(gif: Gif) {
        val sendIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "${gif.title} \n${gif.url}")
            type = "text/plain"
        }
        startActivity(sendIntent)

    }
}