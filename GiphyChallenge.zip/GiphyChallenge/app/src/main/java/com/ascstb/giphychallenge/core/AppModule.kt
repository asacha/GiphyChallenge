package com.ascstb.giphychallenge.core

import android.app.Application
import android.content.Context
import com.ascstb.basedagger.APPLICATION_CONTEXT
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import javax.inject.Named
import javax.inject.Singleton


@Module
internal class AppModule {

    @Provides
    @Singleton
    fun application(app: MyApp): Application = app

    @Provides
    @Singleton
    @Named(APPLICATION_CONTEXT)
    fun applicationContext(app: Application): Context = app.applicationContext

    @Provides
    @Singleton
    fun mainDispatcher(): CoroutineDispatcher = Dispatchers.Main

}